
kmeans_select_groups <- function(Y, number_of_clusters){
  samples <- colnames(Y)
  cov <- cor(Y[, samples], Y[, samples])
  d <- cov
  for(i in 1:nrow(d)) {
    d[i,] <- cov[samples[i], samples]
  }
  d <- 1-d
  c <- c()
  for(i in 1:ncol(d)-1) {
    c <- c(c, d[(i+1):nrow(d),i])
  }
  d <- dist(d)
  for(i in 1:length(d)) {
    d[i] <- c[i]
  }
  km1 <- kmeans(d, number_of_clusters, nstart=100)
  return(list(clusters=km1))
}

kmeans_method <- function(investigated_sample, Y, kmeans_clusters){
  samples <- colnames(Y)
  cluster_id <- kmeans_clusters$cluster[investigated_sample]
  reference_samples <- c()
  list_index <- 1
  for(i in kmeans_clusters$cluster) {
    if(i == cluster_id) {
      reference_samples <- c(reference_samples, samples[list_index])
    }
    list_index <- list_index + 1
  }
  reference_samples <- setdiff(reference_samples, investigated_sample)
  return(list(reference_samples=reference_samples))
}
