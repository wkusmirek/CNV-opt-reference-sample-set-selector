run_REFERENCE.SAMPLE.SET.SELECTOR <- function(num_clusters_max,
                                              input_cov_table,
                                              output_reference_file){

  Y <- data.matrix(read.csv(input_cov_table))
  sampname <- colnames(Y)
  for(num_clusters in 1:num_clusters_max) {
    reference_samples <- list()
    kmeans_clusters <- kmeans_select_groups(Y, num_clusters)$clusters
    for(i in 1:length(sampname)) {
      investigated_sample <- as.character(sampname[i])
      print(paste("Processing ", investigated_sample, " sample ...", sep=""))
      reference_samples_for_investigated_sample <- kmeans_method(investigated_sample, Y, kmeans_clusters)$reference_samples
      reference_samples[[i]] <- c(investigated_sample, reference_samples_for_investigated_sample)
    }
    resultant_string <- ''
    for(i in 1:length(reference_samples)) {
      resultant_string <- paste(resultant_string, paste(reference_samples[[i]], collapse=","), '\n', sep="")
    }
    write(resultant_string, output_reference_file)
  }
}
